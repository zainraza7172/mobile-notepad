@echo off
setlocal
where flutter >nul 2>nul
if errorlevel 1 (
  echo Flutter was not found in PATH.
  echo Install Flutter first, then run this file again.
  pause
  exit /b 1
)
flutter create --platforms=android,ios .
flutter pub get
echo.
echo Setup complete. Run: flutter run
pause
