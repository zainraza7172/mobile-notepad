#!/usr/bin/env bash
set -e
if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter was not found in PATH. Install Flutter first."
  exit 1
fi
flutter create --platforms=android,ios .
flutter pub get
echo "Setup complete. Run: flutter run"
