import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MobileNotepadApp());
}

class MobileNotepadApp extends StatefulWidget {
  const MobileNotepadApp({super.key});

  @override
  State<MobileNotepadApp> createState() => _MobileNotepadAppState();
}

class _MobileNotepadAppState extends State<MobileNotepadApp> {
  final SharedPreferencesAsync _prefs = SharedPreferencesAsync();
  ThemeMode _themeMode = ThemeMode.system;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _loadTheme();
  }

  Future<void> _loadTheme() async {
    final saved = await _prefs.getString('theme_mode');
    if (!mounted) return;
    setState(() {
      _themeMode = switch (saved) {
        'light' => ThemeMode.light,
        'dark' => ThemeMode.dark,
        _ => ThemeMode.system,
      };
      _loaded = true;
    });
  }

  Future<void> _setTheme(ThemeMode mode) async {
    setState(() => _themeMode = mode);
    await _prefs.setString(
      'theme_mode',
      switch (mode) {
        ThemeMode.light => 'light',
        ThemeMode.dark => 'dark',
        ThemeMode.system => 'system',
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF2563EB);
    final lightScheme = ColorScheme.fromSeed(
      seedColor: seed,
      brightness: Brightness.light,
      surface: const Color(0xFFF8F9FB),
    );
    final darkScheme = ColorScheme.fromSeed(
      seedColor: seed,
      brightness: Brightness.dark,
      surface: const Color(0xFF151515),
    );

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Mobile Notepad',
      themeMode: _themeMode,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: lightScheme,
        scaffoldBackgroundColor: Colors.white,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.transparent,
          elevation: 0,
        ),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: darkScheme,
        scaffoldBackgroundColor: const Color(0xFF1E1E1E),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1E1E1E),
          surfaceTintColor: Colors.transparent,
          elevation: 0,
        ),
      ),
      home: _loaded
          ? NotepadScreen(themeMode: _themeMode, onThemeChanged: _setTheme)
          : const Scaffold(body: SizedBox.shrink()),
    );
  }
}

class NotepadScreen extends StatefulWidget {
  const NotepadScreen({
    super.key,
    required this.themeMode,
    required this.onThemeChanged,
  });

  final ThemeMode themeMode;
  final ValueChanged<ThemeMode> onThemeChanged;

  @override
  State<NotepadScreen> createState() => _NotepadScreenState();
}

class _NotepadScreenState extends State<NotepadScreen>
    with WidgetsBindingObserver {
  static const _draftTextKey = 'draft_text';
  static const _draftNameKey = 'draft_name';
  static const _fontSizeKey = 'font_size';
  static const _wordWrapKey = 'word_wrap';

  final SharedPreferencesAsync _prefs = SharedPreferencesAsync();
  final TextEditingController _controller = TextEditingController();
  final FocusNode _editorFocus = FocusNode();
  final TextEditingController _findController = TextEditingController();
  final TextEditingController _replaceController = TextEditingController();

  Timer? _draftTimer;
  Timer? _historyTimer;

  String _fileName = 'Untitled.txt';
  bool _dirty = false;
  bool _wordWrap = true;
  double _fontSize = 16;
  bool _showFind = false;
  bool _replaceMode = false;
  int _currentMatch = -1;
  List<_TextMatch> _matches = const [];

  final List<String> _undoHistory = <String>[''];
  final List<String> _redoHistory = <String>[];
  bool _historyLocked = false;

  int _line = 1;
  int _column = 1;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _controller.addListener(_onControllerChanged);
    _restoreDraft();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _draftTimer?.cancel();
    _historyTimer?.cancel();
    _controller
      ..removeListener(_onControllerChanged)
      ..dispose();
    _editorFocus.dispose();
    _findController.dispose();
    _replaceController.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached) {
      _saveDraftNow();
    }
  }

  Future<void> _restoreDraft() async {
    final draft = await _prefs.getString(_draftTextKey) ?? '';
    final name = await _prefs.getString(_draftNameKey) ?? 'Untitled.txt';
    final size = await _prefs.getDouble(_fontSizeKey) ?? 16;
    final wrap = await _prefs.getBool(_wordWrapKey) ?? true;
    if (!mounted) return;

    _historyLocked = true;
    _controller.text = draft;
    _controller.selection = TextSelection.collapsed(offset: draft.length);
    _historyLocked = false;

    setState(() {
      _fileName = name;
      _fontSize = size.clamp(12.0, 32.0).toDouble();
      _wordWrap = wrap;
      _dirty = draft.isNotEmpty;
      _undoHistory
        ..clear()
        ..add(draft);
      _redoHistory.clear();
    });
    _updateCursorStatus();
  }

  void _onControllerChanged() {
    _updateCursorStatus();
    if (_historyLocked) return;

    setState(() => _dirty = true);
    _scheduleDraftSave();
    _scheduleHistorySnapshot();
    if (_showFind) _rebuildMatches(keepCurrent: true);
  }

  void _scheduleDraftSave() {
    _draftTimer?.cancel();
    _draftTimer = Timer(const Duration(milliseconds: 450), _saveDraftNow);
  }

  Future<void> _saveDraftNow() async {
    await _prefs.setString(_draftTextKey, _controller.text);
    await _prefs.setString(_draftNameKey, _fileName);
    await _prefs.setDouble(_fontSizeKey, _fontSize);
    await _prefs.setBool(_wordWrapKey, _wordWrap);
  }

  void _scheduleHistorySnapshot() {
    _historyTimer?.cancel();
    _historyTimer = Timer(const Duration(milliseconds: 350), () {
      final value = _controller.text;
      if (_undoHistory.isEmpty || _undoHistory.last != value) {
        _undoHistory.add(value);
        if (_undoHistory.length > 100) _undoHistory.removeAt(0);
        _redoHistory.clear();
        if (mounted) setState(() {});
      }
    });
  }

  void _resetHistory(String text) {
    _historyTimer?.cancel();
    _undoHistory
      ..clear()
      ..add(text);
    _redoHistory.clear();
  }

  void _undo() {
    _historyTimer?.cancel();
    final current = _controller.text;
    if (_undoHistory.isEmpty || _undoHistory.last != current) {
      _undoHistory.add(current);
    }
    if (_undoHistory.length <= 1) return;

    final removed = _undoHistory.removeLast();
    _redoHistory.add(removed);
    _setEditorText(_undoHistory.last, markDirty: true);
    setState(() {});
  }

  void _redo() {
    _historyTimer?.cancel();
    if (_redoHistory.isEmpty) return;
    final next = _redoHistory.removeLast();
    _undoHistory.add(next);
    _setEditorText(next, markDirty: true);
    setState(() {});
  }

  void _setEditorText(String text, {required bool markDirty}) {
    _historyLocked = true;
    _controller.value = TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: text.length),
    );
    _historyLocked = false;
    setState(() => _dirty = markDirty);
    _updateCursorStatus();
    _scheduleDraftSave();
  }

  void _updateCursorStatus() {
    final text = _controller.text;
    final selection = _controller.selection;
    final rawOffset = selection.isValid ? selection.extentOffset : text.length;
    final offset = rawOffset.clamp(0, text.length).toInt();
    final before = text.substring(0, offset);
    final lines = before.split('\n');
    final nextLine = lines.length;
    final nextColumn = (lines.isEmpty ? 0 : lines.last.length) + 1;
    if (nextLine != _line || nextColumn != _column) {
      setState(() {
        _line = nextLine;
        _column = nextColumn;
      });
    }
  }

  Future<bool> _confirmDiscardIfNeeded() async {
    if (!_dirty || _controller.text.isEmpty) return true;
    final choice = await showDialog<_DiscardChoice>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Unsaved changes'),
        content: Text('Save changes to $_fileName before continuing?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, _DiscardChoice.cancel),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, _DiscardChoice.discard),
            child: const Text('Don\'t save'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, _DiscardChoice.save),
            child: const Text('Save'),
          ),
        ],
      ),
    );

    if (choice == _DiscardChoice.save) {
      return _saveAs();
    }
    return choice == _DiscardChoice.discard;
  }

  Future<void> _newFile() async {
    if (!await _confirmDiscardIfNeeded()) return;
    _historyLocked = true;
    _controller.clear();
    _historyLocked = false;
    setState(() {
      _fileName = 'Untitled.txt';
      _dirty = false;
      _showFind = false;
      _matches = const [];
      _currentMatch = -1;
    });
    _resetHistory('');
    await _saveDraftNow();
    _editorFocus.requestFocus();
  }

  Future<void> _openFile() async {
    if (!await _confirmDiscardIfNeeded()) return;
    try {
      final PlatformFile? file = await FilePicker.pickFile(
        type: FileType.custom,
        allowedExtensions: const ['txt', 'log', 'md', 'csv', 'json', 'xml'],
      );
      if (file == null) return;

      final Uint8List bytes = await file.readAsBytes();
      final text = utf8.decode(bytes, allowMalformed: true);
      _historyLocked = true;
      _controller.value = TextEditingValue(
        text: text,
        selection: TextSelection.collapsed(offset: text.length),
      );
      _historyLocked = false;
      setState(() {
        _fileName = file.name.isEmpty ? 'Untitled.txt' : file.name;
        _dirty = false;
        _showFind = false;
        _matches = const [];
        _currentMatch = -1;
      });
      _resetHistory(text);
      await _saveDraftNow();
      _editorFocus.requestFocus();
    } catch (error) {
      if (!mounted) return;
      _showSnack('Could not open file: $error');
    }
  }

  Future<bool> _save() => _saveAs();

  Future<bool> _saveAs() async {
    try {
      final safeName = _fileName.trim().isEmpty ? 'Untitled.txt' : _fileName;
      final Uri? result = await FilePicker.saveFile(
        dialogTitle: 'Save text file',
        fileName: safeName.endsWith('.txt') ? safeName : '$safeName.txt',
        bytes: Uint8List.fromList(utf8.encode(_controller.text)),
      );
      if (result == null) return false;

      final segments = result.pathSegments;
      final uriName = segments.isNotEmpty ? segments.last : safeName;
      setState(() {
        _fileName = Uri.decodeComponent(uriName).isEmpty
            ? safeName
            : Uri.decodeComponent(uriName);
        _dirty = false;
      });
      await _saveDraftNow();
      if (mounted) _showSnack('Saved $_fileName');
      return true;
    } catch (error) {
      if (mounted) _showSnack('Could not save file: $error');
      return false;
    }
  }

  void _toggleFind({bool replace = false}) {
    setState(() {
      _showFind = !_showFind || (_replaceMode != replace);
      _replaceMode = replace;
    });
    if (_showFind) {
      _rebuildMatches();
      Future<void>.delayed(const Duration(milliseconds: 100), () {
        if (mounted) FocusScope.of(context).nextFocus();
      });
    } else {
      _editorFocus.requestFocus();
    }
  }

  void _rebuildMatches({bool keepCurrent = false}) {
    final query = _findController.text;
    final text = _controller.text;
    if (query.isEmpty || text.isEmpty) {
      setState(() {
        _matches = const [];
        _currentMatch = -1;
      });
      return;
    }

    final lowerText = text.toLowerCase();
    final lowerQuery = query.toLowerCase();
    final found = <_TextMatch>[];
    var start = 0;
    while (start <= lowerText.length - lowerQuery.length) {
      final index = lowerText.indexOf(lowerQuery, start);
      if (index < 0) break;
      found.add(_TextMatch(index, index + query.length));
      start = index + (query.isEmpty ? 1 : query.length);
    }

    var next = keepCurrent ? _currentMatch : 0;
    if (found.isEmpty) next = -1;
    if (next >= found.length) next = found.length - 1;
    if (next < 0 && found.isNotEmpty) next = 0;
    setState(() {
      _matches = found;
      _currentMatch = next;
    });
    if (next >= 0) _selectMatch(next);
  }

  void _nextMatch() {
    if (_matches.isEmpty) {
      _rebuildMatches();
      return;
    }
    final next = (_currentMatch + 1) % _matches.length;
    setState(() => _currentMatch = next);
    _selectMatch(next);
  }

  void _previousMatch() {
    if (_matches.isEmpty) {
      _rebuildMatches();
      return;
    }
    final next = (_currentMatch - 1 + _matches.length) % _matches.length;
    setState(() => _currentMatch = next);
    _selectMatch(next);
  }

  void _selectMatch(int index) {
    if (index < 0 || index >= _matches.length) return;
    final match = _matches[index];
    _controller.selection = TextSelection(
      baseOffset: match.start,
      extentOffset: match.end,
    );
    _editorFocus.requestFocus();
  }

  void _replaceCurrent() {
    if (_currentMatch < 0 || _currentMatch >= _matches.length) return;
    final match = _matches[_currentMatch];
    final text = _controller.text;
    final replacement = _replaceController.text;
    final updated = text.replaceRange(match.start, match.end, replacement);
    _setEditorText(updated, markDirty: true);
    _rebuildMatches();
  }

  void _replaceAll() {
    final query = _findController.text;
    if (query.isEmpty) return;
    final replacement = _replaceController.text;
    final pattern = RegExp(RegExp.escape(query), caseSensitive: false);
    final updated = _controller.text.replaceAll(pattern, replacement);
    if (updated == _controller.text) return;
    _setEditorText(updated, markDirty: true);
    _resetHistory(updated);
    _rebuildMatches();
  }

  Future<void> _setWordWrap(bool value) async {
    setState(() => _wordWrap = value);
    await _prefs.setBool(_wordWrapKey, value);
  }

  Future<void> _changeFontSize(double delta) async {
    final next = (_fontSize + delta).clamp(12.0, 32.0).toDouble();
    setState(() => _fontSize = next);
    await _prefs.setDouble(_fontSizeKey, next);
  }

  Future<void> _resetFontSize() async {
    setState(() => _fontSize = 16);
    await _prefs.setDouble(_fontSizeKey, 16);
  }

  void _selectAll() {
    _controller.selection = TextSelection(
      baseOffset: 0,
      extentOffset: _controller.text.length,
    );
    _editorFocus.requestFocus();
  }

  void _showSnack(String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  double _noWrapWidth(double viewportWidth) {
    if (_wordWrap) return viewportWidth;
    final lines = _controller.text.split('\n');
    var longest = 0;
    for (final line in lines) {
      if (line.length > longest) longest = line.length;
    }
    final estimated = longest * (_fontSize * 0.62) + 48;
    return estimated < viewportWidth ? viewportWidth : estimated;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    final shortcuts = <ShortcutActivator, VoidCallback>{
      const SingleActivator(LogicalKeyboardKey.keyN, control: true): _newFile,
      const SingleActivator(LogicalKeyboardKey.keyO, control: true): _openFile,
      const SingleActivator(LogicalKeyboardKey.keyS, control: true): _save,
      const SingleActivator(LogicalKeyboardKey.keyF, control: true):
          () => _toggleFind(),
      const SingleActivator(LogicalKeyboardKey.keyH, control: true):
          () => _toggleFind(replace: true),
      const SingleActivator(LogicalKeyboardKey.keyZ, control: true): _undo,
      const SingleActivator(LogicalKeyboardKey.keyY, control: true): _redo,
      const SingleActivator(LogicalKeyboardKey.keyA, control: true): _selectAll,
    };

    return PopScope(
      canPop: !_dirty,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        final canLeave = await _confirmDiscardIfNeeded();
        if (canLeave && context.mounted) Navigator.of(context).pop();
      },
      child: CallbackShortcuts(
        bindings: shortcuts,
        child: Scaffold(
          appBar: AppBar(
            titleSpacing: 12,
            title: Row(
              children: [
                const Icon(Icons.description_outlined, size: 21),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '${_dirty ? '• ' : ''}$_fileName',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                  ),
                ),
              ],
            ),
            actions: [
              IconButton(
                tooltip: 'Undo',
                onPressed: _undoHistory.length > 1 ? _undo : null,
                icon: const Icon(Icons.undo_rounded),
              ),
              IconButton(
                tooltip: 'Redo',
                onPressed: _redoHistory.isNotEmpty ? _redo : null,
                icon: const Icon(Icons.redo_rounded),
              ),
              IconButton(
                tooltip: 'Save',
                onPressed: _save,
                icon: const Icon(Icons.save_outlined),
              ),
              PopupMenuButton<_MenuAction>(
                tooltip: 'Menu',
                onSelected: _handleMenu,
                itemBuilder: (context) => [
                  const PopupMenuItem(
                    value: _MenuAction.newFile,
                    child: _MenuRow(Icons.note_add_outlined, 'New'),
                  ),
                  const PopupMenuItem(
                    value: _MenuAction.open,
                    child: _MenuRow(Icons.folder_open_outlined, 'Open'),
                  ),
                  const PopupMenuItem(
                    value: _MenuAction.saveAs,
                    child: _MenuRow(Icons.save_as_outlined, 'Save as'),
                  ),
                  const PopupMenuDivider(),
                  const PopupMenuItem(
                    value: _MenuAction.find,
                    child: _MenuRow(Icons.search, 'Find'),
                  ),
                  const PopupMenuItem(
                    value: _MenuAction.replace,
                    child: _MenuRow(Icons.find_replace, 'Replace'),
                  ),
                  const PopupMenuItem(
                    value: _MenuAction.selectAll,
                    child: _MenuRow(Icons.select_all, 'Select all'),
                  ),
                  const PopupMenuDivider(),
                  PopupMenuItem(
                    value: _MenuAction.wordWrap,
                    child: _MenuRow(
                      _wordWrap ? Icons.check_box : Icons.check_box_outline_blank,
                      'Word wrap',
                    ),
                  ),
                  const PopupMenuItem(
                    value: _MenuAction.zoomIn,
                    child: _MenuRow(Icons.zoom_in, 'Increase text size'),
                  ),
                  const PopupMenuItem(
                    value: _MenuAction.zoomOut,
                    child: _MenuRow(Icons.zoom_out, 'Decrease text size'),
                  ),
                  const PopupMenuItem(
                    value: _MenuAction.zoomReset,
                    child: _MenuRow(Icons.restart_alt, 'Reset text size'),
                  ),
                  const PopupMenuDivider(),
                  PopupMenuItem(
                    value: _MenuAction.theme,
                    child: _MenuRow(
                      isDark ? Icons.dark_mode_outlined : Icons.light_mode_outlined,
                      'Theme',
                    ),
                  ),
                ],
              ),
            ],
            bottom: PreferredSize(
              preferredSize: Size.fromHeight(_showFind ? (_replaceMode ? 112 : 62) : 1),
              child: Column(
                children: [
                  Divider(height: 1, color: theme.dividerColor.withValues(alpha: .55)),
                  if (_showFind) _buildFindPanel(context),
                ],
              ),
            ),
          ),
          body: Column(
            children: [
              Expanded(
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final editorWidth = _noWrapWidth(constraints.maxWidth);
                    final editor = SizedBox(
                      width: editorWidth,
                      child: TextField(
                        controller: _controller,
                        focusNode: _editorFocus,
                        autofocus: true,
                        keyboardType: TextInputType.multiline,
                        textInputAction: TextInputAction.newline,
                        maxLines: null,
                        minLines: null,
                        expands: true,
                        textAlignVertical: TextAlignVertical.top,
                        style: TextStyle(
                          fontFamily: 'monospace',
                          fontSize: _fontSize,
                          height: 1.45,
                        ),
                        decoration: const InputDecoration(
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.fromLTRB(14, 12, 14, 24),
                          hintText: 'Start typing…',
                        ),
                      ),
                    );

                    if (_wordWrap) return editor;
                    return SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: editor,
                    );
                  },
                ),
              ),
              _StatusBar(
                line: _line,
                column: _column,
                fontSize: _fontSize,
                characters: _controller.text.length,
                words: _wordCount(_controller.text),
                wrap: _wordWrap,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFindPanel(BuildContext context) {
    final theme = Theme.of(context);
    return Material(
      color: theme.colorScheme.surfaceContainerLowest,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(8, 6, 8, 7),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _findController,
                    onChanged: (_) => _rebuildMatches(),
                    decoration: const InputDecoration(
                      isDense: true,
                      border: OutlineInputBorder(),
                      hintText: 'Find',
                      prefixIcon: Icon(Icons.search, size: 20),
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  _matches.isEmpty ? '0/0' : '${_currentMatch + 1}/${_matches.length}',
                  style: theme.textTheme.bodySmall,
                ),
                IconButton(
                  tooltip: 'Previous',
                  onPressed: _previousMatch,
                  icon: const Icon(Icons.keyboard_arrow_up),
                ),
                IconButton(
                  tooltip: 'Next',
                  onPressed: _nextMatch,
                  icon: const Icon(Icons.keyboard_arrow_down),
                ),
                IconButton(
                  tooltip: 'Close',
                  onPressed: () => setState(() => _showFind = false),
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
            if (_replaceMode) ...[
              const SizedBox(height: 6),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _replaceController,
                      decoration: const InputDecoration(
                        isDense: true,
                        border: OutlineInputBorder(),
                        hintText: 'Replace with',
                        prefixIcon: Icon(Icons.find_replace, size: 20),
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  TextButton(onPressed: _replaceCurrent, child: const Text('Replace')),
                  TextButton(onPressed: _replaceAll, child: const Text('All')),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _handleMenu(_MenuAction action) async {
    switch (action) {
      case _MenuAction.newFile:
        await _newFile();
      case _MenuAction.open:
        await _openFile();
      case _MenuAction.saveAs:
        await _saveAs();
      case _MenuAction.find:
        _toggleFind();
      case _MenuAction.replace:
        _toggleFind(replace: true);
      case _MenuAction.selectAll:
        _selectAll();
      case _MenuAction.wordWrap:
        await _setWordWrap(!_wordWrap);
      case _MenuAction.zoomIn:
        await _changeFontSize(1);
      case _MenuAction.zoomOut:
        await _changeFontSize(-1);
      case _MenuAction.zoomReset:
        await _resetFontSize();
      case _MenuAction.theme:
        if (!mounted) return;
        await showModalBottomSheet<void>(
          context: context,
          showDragHandle: true,
          builder: (context) => _ThemeSheet(
            current: widget.themeMode,
            onChanged: (mode) {
              widget.onThemeChanged(mode);
              Navigator.pop(context);
            },
          ),
        );
    }
  }

  int _wordCount(String text) {
    final trimmed = text.trim();
    if (trimmed.isEmpty) return 0;
    return trimmed.split(RegExp(r'\s+')).length;
  }
}

class _MenuRow extends StatelessWidget {
  const _MenuRow(this.icon, this.label);

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 20),
        const SizedBox(width: 12),
        Text(label),
      ],
    );
  }
}

class _ThemeSheet extends StatelessWidget {
  const _ThemeSheet({required this.current, required this.onChanged});

  final ThemeMode current;
  final ValueChanged<ThemeMode> onChanged;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            RadioListTile<ThemeMode>(
              value: ThemeMode.system,
              groupValue: current,
              onChanged: (value) => value == null ? null : onChanged(value),
              title: const Text('Use device setting'),
            ),
            RadioListTile<ThemeMode>(
              value: ThemeMode.light,
              groupValue: current,
              onChanged: (value) => value == null ? null : onChanged(value),
              title: const Text('Light'),
            ),
            RadioListTile<ThemeMode>(
              value: ThemeMode.dark,
              groupValue: current,
              onChanged: (value) => value == null ? null : onChanged(value),
              title: const Text('Dark'),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatusBar extends StatelessWidget {
  const _StatusBar({
    required this.line,
    required this.column,
    required this.fontSize,
    required this.characters,
    required this.words,
    required this.wrap,
  });

  final int line;
  final int column;
  final double fontSize;
  final int characters;
  final int words;
  final bool wrap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      height: 34,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerLow,
        border: Border(top: BorderSide(color: theme.dividerColor.withValues(alpha: .45))),
      ),
      child: Row(
        children: [
          Text('Ln $line, Col $column', style: theme.textTheme.labelSmall),
          const Spacer(),
          Text('$words words', style: theme.textTheme.labelSmall),
          const SizedBox(width: 12),
          Text('$characters chars', style: theme.textTheme.labelSmall),
          const SizedBox(width: 12),
          Text('${fontSize.round()} px', style: theme.textTheme.labelSmall),
          const SizedBox(width: 12),
          Icon(wrap ? Icons.wrap_text : Icons.horizontal_rule, size: 15),
          const SizedBox(width: 4),
          Text('UTF-8', style: theme.textTheme.labelSmall),
        ],
      ),
    );
  }
}

class _TextMatch {
  const _TextMatch(this.start, this.end);
  final int start;
  final int end;
}

enum _DiscardChoice { save, discard, cancel }

enum _MenuAction {
  newFile,
  open,
  saveAs,
  find,
  replace,
  selectAll,
  wordWrap,
  zoomIn,
  zoomOut,
  zoomReset,
  theme,
}
