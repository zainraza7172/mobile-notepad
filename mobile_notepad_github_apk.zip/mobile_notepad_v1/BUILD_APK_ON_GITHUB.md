# Build the APK with GitHub — Phone Friendly

You do **not** need Android Studio or Flutter installed on your phone/PC.
GitHub Actions will build the Android APK in the cloud.

## First upload

1. Sign in to GitHub and create a **new repository**.
2. Extract this ZIP.
3. Upload the **contents inside** the `mobile_notepad_v1` folder to the repository root.
   - Important: `.github/workflows/build-apk.yml` must end up at exactly that path in the repository.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab.
6. Open **Build Android APK**.
7. If a build did not start automatically, tap **Run workflow** and choose `main`.
8. When the run is green, open it and scroll to **Artifacts**.
9. Download **Mobile-Notepad-APK**.
10. GitHub downloads the artifact as a ZIP. Extract it and install `Mobile-Notepad.apk` on Android.

## What the workflow does

- Uses Ubuntu on GitHub's hosted runner.
- Installs Java 17.
- Installs the current stable Flutter SDK.
- Automatically creates the missing Android Flutter platform files.
- Sets Android minimum SDK to 24 because `shared_preferences 2.5.5` supports Android SDK 24+.
- Runs `flutter pub get`.
- Runs `flutter build apk --release`.
- Renames the result to `Mobile-Notepad.apk`.
- Uploads the APK as a GitHub Actions artifact for 14 days.

## Rebuild later

Every push to `main` or `master` triggers another APK build. You can also run it manually from:

**Actions → Build Android APK → Run workflow**

## If Android blocks installation

Android may ask you to allow **Install unknown apps** for your browser or file manager. Allow it only for the app you are using to open this APK, install the APK, then turn the permission back off if you prefer.

## Play Store note

This workflow produces an installable APK for testing/private installation. A Play Store release should use your own application ID, signing keystore, and an Android App Bundle (`.aab`).
