# Mobile Notepad v0.1

A clean Windows-Notepad-inspired mobile text editor built with Flutter.

## Included in v0.1

- New document
- Open TXT / LOG / MD / CSV / JSON / XML
- Save / Save As through the phone's native file picker
- UTF-8 text
- Undo / Redo (100-state history)
- Find / Replace / Replace All
- Word-wrap toggle
- Font size controls
- Light / Dark / System theme
- Auto-save draft and restore after reopening the app
- Unsaved-change warning
- Line / column, words, characters and encoding status bar
- Hardware keyboard shortcuts:
  - Ctrl+N New
  - Ctrl+O Open
  - Ctrl+S Save
  - Ctrl+F Find
  - Ctrl+H Replace
  - Ctrl+Z Undo
  - Ctrl+Y Redo
  - Ctrl+A Select All

## Important Android Save behavior

This first build deliberately uses Android's Storage Access Framework through `file_picker` so it does not request broad storage permissions. On Android, Save currently opens the native save chooser. Persistent in-place saving to the exact same selected document URI is planned for v0.2 with a small native Android bridge.

## Requirements

- Flutter with Dart 3.10+
- Android Studio (for Android APK/AAB)

Dependencies used:

- `file_picker: ^13.1.0`
- `shared_preferences: ^2.5.5`


## Build APK on GitHub (no Android Studio required)

This package now includes `.github/workflows/build-apk.yml`. Upload the project contents to a GitHub repository and GitHub Actions will generate an installable `Mobile-Notepad.apk`.

See **BUILD_APK_ON_GITHUB.md** for phone-friendly step-by-step instructions.

## Create platform folders and run

This source bundle intentionally keeps platform-generated Flutter files out of the ZIP so you can generate them using the exact Flutter version installed on your computer.

From the folder containing `pubspec.yaml`:

```bash
flutter create --platforms=android,ios .
flutter pub get
flutter run
```

If `flutter create` replaces `lib/main.dart` on your Flutter installation, restore `lib/main.dart` from this ZIP afterward, then run `flutter pub get` again.

## Build Android APK

```bash
flutter build apk --release
```

Output is normally:

```text
build/app/outputs/flutter-apk/app-release.apk
```

## Next milestone (v0.2)

- True in-place Save to the same opened Android document URI
- Recent files
- Multiple tabs
- Share text / file
- Print
- Encoding selector
- Go To line
- Better large-file performance
- Android launcher icon and final product branding
